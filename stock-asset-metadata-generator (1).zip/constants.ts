
export const MARKETPLACES: string[] = [
  "Adobe Stock",
  "Shutterstock",
  "123RF",
  "Getty Images",
  "iStock",
  "Pond5",
  "Vecteezy"
];
